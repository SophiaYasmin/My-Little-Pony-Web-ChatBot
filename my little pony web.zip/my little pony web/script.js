const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Estrutura de dados para as respostas
const responses = {
    "quem é a twilight sparkle?": "Eu sou a Twilight Sparkle, a princesa da amizade!",
    "o que é amizade?": "Amizade é um laço especial entre amigos que se apoiam e se cuidam.",
    "quem são seus amigos?": "Meus amigos são a Applejack, a Rarity, a Rainbow Dash, a Fluttershy e a Pinkie Pie!",
    "qual é o seu maior medo?": "Meu maior medo é perder meus amigos e não conseguir ajudá-los.",
    "o que você faz como princesa?": "Como princesa, eu ajudo a espalhar a amizade e a resolver problemas entre os ponies.",
    "qual é a sua cor favorita?": "Minha cor favorita é roxo, é a cor da magia!",
    "o que você aprendeu sobre amizade?": "Aprendi que a amizade é um dos maiores tesouros que podemos ter!",
    "quem é o seu mentor?": "Meu mentor é a Princesa Celestia, que me ensinou muito sobre magia e amizade.",
    "qual é o seu livro favorito?": "Meu livro favorito é 'O Guia da Amizade'!",
    "o que você gosta de fazer?": "Eu adoro estudar e passar tempo com meus amigos!",
    "quem é o vilão mais famoso?": "Um dos vilões mais famosos é a Rainha Chrysalis, a líder dos Changelings.",
    "o que é magia?": "Magia é uma força poderosa que pode ser usada para fazer coisas incríveis!",
    "qual é a sua cidade?": "Eu moro em Ponyville, uma cidade cheia de amigos e aventuras!",
    "quem é o seu animal de estimação?": "Meu animal de estimação é Spike, um dragão que é como um irmão para mim!",
    "o que você acha da amizade?": "A amizade é a coisa mais importante do mundo! Ela nos une e nos fortalece.",
    "Qual é o seu feitiço favorito?": "É difícil escolher apenas um, mas eu adoro usar feitiços de teletransporte. Eles economizam muito tempo, especialmente quando estou correndo para resolver uma emergência em Ponyville!",
    "Como posso aprender algo novo rapidamente?": "Ótima pergunta! Minha dica é dividir o que você quer aprender em partes menores e estudar um pouco a cada dia. E, claro, não tenha medo de fazer perguntas ou buscar ajuda – é assim que aprendemos!",
    "O que você gosta de fazer no seu tempo livre?": " Eu adoro ler! Não há nada melhor do que mergulhar em um bom livro, seja sobre magia, história de Equestria ou aventuras emocionantes.",
    "Você tem um conselho para trabalhar em equipe?": " Com certeza! O mais importante em uma equipe é a comunicação. Certifique-se de ouvir todos os membros e valorizar suas contribuições. E lembre-se: cada pônei tem algo único para oferecer!",
    "O que amizade significa para você?": "Amizade é mágica! É sobre cuidar uns dos outros, aprender com as diferenças e estar presente para seus amigos, não importa o que aconteça.",
    "Twilight, qual é sua cor favorita?": " Ah, essa é fácil! Eu adoro o roxo, é claro! Combina perfeitamente com minha crina e pele.",
};

// Função para adicionar mensagens ao chat
function addMessageToChatBox(message, sender) {
    const messageElement = document.createElement('p');
    messageElement.textContent = `${sender}: ${message}`;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Rolagem automática
}

// Função para normalizar a entrada do usuário
function normalizeInput(input) {
    return input.trim().toLowerCase();
}

// Função para obter a resposta
function getResponse(userMessage) {
    const normalizedMessage = normalizeInput(userMessage);
    
    // Verifica se a mensagem está nas respostas
    if (responses[normalizedMessage]) {
        return responses[normalizedMessage];
    } else {
        return "Desculpe, não sei a resposta para isso. Você pode perguntar sobre amizade ou sobre mim!";
    }
}

// Evento de clique no botão de enviar
sendButton.addEventListener('click', () => {
    const userMessage = userInput.value;
    if (userMessage) {
        addMessageToChatBox(userMessage, 'Você');
        const response = getResponse(userMessage);
        addMessageToChatBox(response, 'Twilight Sparkle');
        userInput.value = '';
    }
});

// Evento de pressionar a tecla Enter
userInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        sendButton.click();
    }
});